package com.readygo;
public class Driver {

	private int driverId;
	private String driverFname;
	private String driverLname;
	private long contactNo;
	private boolean licenceAvailable;
	private int experience;
	private String address;
	private String email;
	private String password;
	private String cpassword;
	private String city;
	private String image;
	
	
	public int getDriverId() {
		return driverId;
	}
	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}
	public String getDriverFname() {
		return driverFname;
	}
	public void setDriverFname(String driverFname) {
		this.driverFname = driverFname;
	}
	public String getDriverLname() {
		return driverLname;
	}
	public void setDriverLname(String driverLname) {
		this.driverLname = driverLname;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public boolean isLicenceAvailable() {
		return licenceAvailable;
	}
	public void setLicenceAvailable(boolean licenceAvailable) {
		this.licenceAvailable = licenceAvailable;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "Driver [driverId=" + driverId + ", driverFname=" + driverFname + ", driverLname=" + driverLname
				+ ", contactNo=" + contactNo + ", licenceAvailable=" + licenceAvailable + ", experience=" + experience
				+ ", address=" + address + ", email=" + email + ", password=" + password + ", cpassword=" + cpassword
				+ ", city=" + city + ", image=" + image + "]";
	}
	
	
}
