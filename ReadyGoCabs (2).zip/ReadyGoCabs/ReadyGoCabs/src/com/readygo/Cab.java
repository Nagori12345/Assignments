package com.readygo;
public class Cab {
	private int cabId;
	private String cabOwner;
	private String cabCompany;
	private String cabModel;
	private String cabNumber;
	private int sitCapacity;
	private String cabType;
	private boolean cabAvailability;
	private boolean ac;
	private String cabImage;
	private int yearOfMfg;
	
	
	public int getCabId() {
		return cabId;
	}
	public void setCabId(int cabId) {
		this.cabId = cabId;
	}
	public String getCabOwner() {
		return cabOwner;
	}
	public void setCabOwner(String cabOwner) {
		this.cabOwner = cabOwner;
	}
	public String getCabCompany() {
		return cabCompany;
	}
	public void setCabCompany(String cabCompany) {
		this.cabCompany = cabCompany;
	}
	public String getCabModel() {
		return cabModel;
	}
	public void setCabModel(String cabModel) {
		this.cabModel = cabModel;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public int getSitCapacity() {
		return sitCapacity;
	}
	public void setSitCapacity(int sitCapacity) {
		this.sitCapacity = sitCapacity;
	}
	public String getCabType() {
		return cabType;
	}
	public void setCabType(String cabType) {
		this.cabType = cabType;
	}
	public boolean isCabAvailability() {
		return cabAvailability;
	}
	public void setCabAvailability(boolean cabAvailability) {
		this.cabAvailability = cabAvailability;
	}
	public boolean isAc() {
		return ac;
	}
	public void setAc(boolean ac) {
		this.ac = ac;
	}
	public String getCabImage() {
		return cabImage;
	}
	public void setCabImage(String cabImage) {
		this.cabImage = cabImage;
	}
	public int getYearOfMfg() {
		return yearOfMfg;
	}
	public void setYearOfMfg(int yearOfMfg) {
		this.yearOfMfg = yearOfMfg;
	}
	@Override
	public String toString() {
		return "Cab [cabId=" + cabId + ", cabOwner=" + cabOwner + ", cabCompany=" + cabCompany + ", cabModel="
				+ cabModel + ", cabNumber=" + cabNumber + ", sitCapacity=" + sitCapacity + ", cabType=" + cabType
				+ ", cabAvailability=" + cabAvailability + ", ac=" + ac + ", cabImage=" + cabImage + ", yearOfMfg="
				+ yearOfMfg + "]";
	}
	
	
	
}
