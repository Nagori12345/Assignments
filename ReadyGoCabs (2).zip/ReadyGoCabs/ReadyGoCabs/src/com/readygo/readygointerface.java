package com.readygo;
public interface readygointerface {
	public User addUser(int userId,String fName, String lName,long contact,String email,String address,String city,String password,String cPassword,String image,boolean role);
	public Driver addDriver(int idOfDriver,String fname,String lname,long contNo,boolean lAvail,int exp,String addr,String mail,String pass,String cpass,String ct,String img);
	public Cab addCab(String ownerName,String company,String model,String number,int sitCapacity,String typeOfCab,boolean acSystem,int mfgYear,int idOfCab);
}
