package com.deloitte.library.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.deloitte.library.model.Books;

public class BooksDAO {
	public static Connection connectToDB() {
		// register the driver
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
			}
		}

	public static void addBook(Books library) {
		// TODO Auto-generated method stub
		System.out.println(library);
		try {
			// step 3 Create Statement
			Connection conn = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Books values(?,?,?,?)");
			stmt.setInt(1, library.getBookId());
			stmt.setString(2, library.getBookName());
			stmt.setString(3, library.getBookAuthor());
			stmt.setDouble(4, library.getBookPrice());
			int affectedRows = stmt.executeUpdate();
			System.out.println(affectedRows+"Affaected Rows");
			conn.close();
			//step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
