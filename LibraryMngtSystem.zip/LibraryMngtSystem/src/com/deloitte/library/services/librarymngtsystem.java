package com.deloitte.library.services;

import java.util.ArrayList;

import com.deloitte.library.model.Books;

public interface librarymngtsystem {
	public void addBooks(String bookName, Double bookPrice,String bookAuthor);
	public ArrayList<Books> displayBooks();
}
 