package com.readygo;
public interface readygointerface {
	public void addUser();
	public void addDriver();
	public void addCab();
}
