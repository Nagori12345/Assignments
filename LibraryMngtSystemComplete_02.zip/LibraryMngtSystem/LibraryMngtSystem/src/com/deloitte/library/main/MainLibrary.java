package com.deloitte.library.main;

import java.util.ArrayList;
import java.util.Scanner;

import com.deloitte.library.model.Books;
import com.deloitte.library.services.LibraryImpl;

public class MainLibrary {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		LibraryImpl libraryimplmain = new LibraryImpl();
		ArrayList<Books> books = new ArrayList<Books>();
//		int bookId = Books.getBookId();
		while (true) {
			System.out.println("Press 1 to Add Book \n2 to Display Books \n3 to exit");
			int option = s.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Book Name");
				String bookName = s.next();
				System.out.println("Enter Book Price");
				Double bookPrice = s.nextDouble();
				System.out.println("Enter Author Name");
				String bookAuthor = s.next();
				libraryimplmain.addBooks(bookName, bookPrice, bookAuthor);
				break;

			case 2:
				
				libraryimplmain.displayBooks();

			case 3:
				System.exit(0);
			}
		}
	}
}
