function validate(){
	var x = fname();
	alert(x);
	alert("hubhh");
	var y = lname();
	alert(y);
	if(x && y){
		return true;
	}
	else{
		return false;
	}
}


function fname(){
	var firstName = document.getElementById("fName").value;
	var fNamePattern = "^[A-Za-z]+$";
	if(!firstName.match(fNamePattern)){
		document.getElementById("fNameError").innerHTML="First Name should be only Alphabets";
		document.getElementById("fNameError").style.color="red";
		return false;
	}
	else{
		document.getElementById("fNameError").innerHTML="";
		return true;
	}
}

function lname(){
	var lastName = document.getElementById("lName").value;
	var lNamePattern = "^[A-Za-z]+$";
	if(!lastName.match(lNamePattern)){
		document.getElementById("lNameError").innerHTML="Last Name should be only Alphabets";
		document.getElementById("lNameError").style.color="red";
		return false;
	}
	else{
		document.getElementById("lNameError").innerHTML="";
		return true;
	}
}