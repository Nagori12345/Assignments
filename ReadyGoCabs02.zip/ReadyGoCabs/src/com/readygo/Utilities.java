package com.readygo;

public class Utilities {

}
