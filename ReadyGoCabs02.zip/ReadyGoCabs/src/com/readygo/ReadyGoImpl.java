package com.readygo;

import java.util.ArrayList;

public class ReadyGoImpl implements readygointerface{

	@Override
	public User addUser(int userId,String fName, String lName,long contact,String email,String address,String city,String password,String cPassword,String image,boolean role) {
		// TODO Auto-generated method stub
		User user = new User();
		user.setUserId(userId);
		user.setfName(fName);
		user.setlName(lName);
		user.setContact(contact);
		user.setEmail(email);
		user.setAddress(address);
		user.setCity(city);
		user.setPassword(password);
		user.setcPassword(cPassword);
		user.setImage(image);
		user.isRole();
		return user;
	}

	@Override
	public Driver addDriver(int idOfDriver,String fname,String lname,long contNo,boolean lAvail,int exp,String addr,String mail,String pass,String cpass,String ct,String img) {
		// TODO Auto-generated method stub
		Driver driver = new Driver();
		driver.setDriverId(idOfDriver);
		driver.setDriverFname(fname);
		driver.setDriverLname(lname);
		driver.setContactNo(contNo);
		driver.setLicenceAvailable(lAvail);
		driver.setExperience(exp);
		driver.setAddress(addr);
		driver.setEmail(mail);
		driver.setPassword(pass);
		driver.setCpassword(cpass);
		driver.setCity(ct);
		driver.setImage(img);
		return driver;
	}

	@Override
	public Cab addCab(String ownerName,String company,String model,String number,int sitCapacity,String typeOfCab,boolean acSystem,int mfgYear,int idOfCab) {
		// TODO Auto-generated method stub
		Cab cabs = new Cab();
		cabs.setCabOwner(ownerName);
		cabs.setCabCompany(company);
		cabs.setCabModel(model);
		cabs.setCabNumber(number);
		cabs.setSitCapacity(sitCapacity);
		cabs.setCabType(typeOfCab);
		cabs.setAc(acSystem);
		cabs.setYearOfMfg(mfgYear);
		cabs.setCabId(idOfCab);
		return cabs;
		
	}

	@Override
	public boolean signIn(int checkUserId, String checkUserPassword) {
		// TODO Auto-generated method stub
		if(checkUserId==101 && checkUserPassword.equals("Admin")) {
			return true;
		}
		else {
			return false;
		}
	}
	
}
