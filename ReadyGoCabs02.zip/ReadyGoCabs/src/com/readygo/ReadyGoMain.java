package com.readygo;

import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ReadyGoMain {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<Cab> cabDetails = new ArrayList<Cab>();
		ArrayList<User> userDetails = new ArrayList<User>();
		ArrayList<Driver> driverDetails = new ArrayList<Driver>();
		ReadyGoImpl readyGoImpl = new ReadyGoImpl();
		while (true) {
			System.out.println(
					"Please Press :  \n	1 to SignUp As Customer. \n	2 to SignUp As Driver. \n	3 to Attach Your Cab With Us. \n	4 to SignIn");
			int choice = s.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Your User Id:");
				int userId = s.nextInt();
				System.out.println("Enter Your First Name:");
				String fName = s.next();
				System.out.println("Enter Your Last Name:");
				String lName = s.next();
				System.out.println("Enter Your Contact Number:");
				long contact = s.nextLong();
				System.out.println("Enter Your Email-Id:");
				String email = s.next();
				System.out.println("Enter Your Address:");
				String address = s.next();
				System.out.println("Enter Your city:");
				String city = s.next();
				System.out.println("Enter Your password:");
				String password = s.next();
				System.out.println("Enter Your Confirmation password:");
				String cPassword = s.next();
				System.out.println("Enter Your Image:");
				String image = s.next();
				System.out.println("Enter Your Role:");
				boolean role = s.nextBoolean();

				userDetails.add(readyGoImpl.addUser(userId, fName, lName, contact, email, address, city, password,
						cPassword, image, role));
				System.out.println(userDetails);
				break;
				
			case 2:
				System.out.println("Enter your DriverId : ");
				int idOfDriver = s.nextInt();
				System.out.println("Enter your First name : ");
				String fname = s.next();
				System.out.println("Enter your Last name : ");
				String lname = s.next();
				System.out.println("Enter your mobile number : ");
				long contNo = s.nextLong();
				System.out.println("Do you have licence : ");
				boolean lAvail = s.nextBoolean();
				System.out.println("Years of Experience : ");
				int exp = s.nextInt();
				System.out.println("Enter your address : ");
				String addr = s.next();
				System.out.println("Enter your email id : ");
				String mail = s.next();
				System.out.println("Enter your password : ");
				String pass = s.next();
				System.out.println("Re-enter your password : ");
				String cpass = s.next();
				System.out.println("Enter your city");
				String ct = s.next();
				System.out.println("Upload your image : ");
				String img = s.next();
				driverDetails.add(readyGoImpl.addDriver(idOfDriver, fname, lname, contNo, lAvail, exp, addr, mail, pass,
						cpass, ct, img));
				System.out.println(driverDetails);
				break;

			case 3:
				System.out.println("Enter Cab Id");
				int idOfCab = s.nextInt();
				System.out.println("Enter Cab Owner Name");
				String ownerName = s.next();
				System.out.println("Enter Company of Cab");
				String company = s.next();
				System.out.println("Enter Model of Cab");
				String model = s.next();
				System.out.println("Enter Number of Cab");
				String number = s.next();
				System.out.println("Enter Sitting Capacity of Cab");
				int sitCapacity = s.nextInt();
				System.out.println("Enter Type of Cab");
				String typeOfCab = s.next();
				System.out.println("Is AC Available");
				boolean acSystem = s.nextBoolean();
				System.out.println("Enter Manufacturing Year of Cab");
				int mfgYear = s.nextInt();

				cabDetails.add(readyGoImpl.addCab(ownerName, company, model, number, sitCapacity, typeOfCab, acSystem,
						mfgYear, idOfCab));
				System.out.println(cabDetails);
				break;
				
			case 4:
				System.out.println("Enter UserId");
				int checkUserId = s.nextInt();
				System.out.println("Enter Password");
				String checkUserPassword = s.next();
				
				boolean validateLogin = readyGoImpl.signIn(checkUserId, checkUserPassword);
				if(validateLogin) {
					System.out.println("Login Successfully");
				}
				else {
					System.out.println("User Name Or Password Is Wrong");
				}
				break;
			}
		}
	}
}